import 'package:flutter/material.dart';

class DetailsScreen extends StatelessWidget {
  static const name = 'details-screen';

  const DetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('Detalle de Pantalla')),
        elevation: 2,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black,
      ), // AppBar
      body: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: const Text(
                'El ordenador nació para resolver problemas que antes no existían'),
          ),
        ],
      ),
    ); // Scaffold
  }
}
