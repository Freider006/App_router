import 'package:app_router/presentation/screens/details_screen.dart';
import 'package:app_router/presentation/screens/home_screen.dart';
import 'package:go_router/go_router.dart';

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      name: HomeScreens.name,
      builder: (context, state) => const HomeScreens(),
      routes: [
        GoRoute(
          path: 'details',
          name: DetailsScreen.name,
          builder: (context, state) => const DetailsScreen(),
        ),
      ],
    ),
  ],
);
